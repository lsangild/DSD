Unicode Version of VHdl Notepad++ plugin  --> Austria edition
	
	Tested with version 5.1.3 of Notepad++ (unicode version)

#####################################################################
         INFO                                                    
#####################################################################
Copy the file tmp_testbench.vhd and VhdlPlugin.dll into the plugin 
directroy  of Notepad++. After openning Notepad++ the plugin should be
available in the Plugin men�.
 To use it select the whole entity then press ALT+f or use the plugin 
men� "VHDL copy Entity". 

Use for example ALT+i to paste the instantiation of this copied entity 
or use the "Insert Instantiation" entry in the plugin men�.
The tmp_testbench.vhd is used to paste the testbench. You can edit 
this file to adopt it to your needs.
The names $ENTITY_SIGNALS$  $ENTITY_INSTANTIATION_93$  $ENTITY_NAME$ in 
the tmp_testbench.vhd file are replaced by the corresponding data. 

$ENTITY_SIGNALS$............will be replaced by all the signals of the copied entity
$ENTITY_INSTANTIATION_93$...will be replaced by the Instantiation of the copied entity
$ENTITY_NAME$...............will be replaced by the name of the copied entity

#####################################################################
         Release Note                                            
#####################################################################
This is my first alpha alpha release. For Questions or Suggestions
please write (Norbert.Feurle@gmx.at)

